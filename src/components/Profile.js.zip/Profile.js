import React, { useState } from "react";
import SearchDescription from "./SearchDescription";
import Cookies from "js-cookie";
import NavBar from "../components/NavBar";
import Footer from "../components/Footer";
import axios from "axios";
import "../components/ProfileCard.scss";
import { Link, useHistory } from "react-router-dom";
import Loading from "../components/Loading";

export default function Profile(props) {
  // const loggedinUser = props.match.params.username
  console.log("props in profile page", props);
  const user = Cookies.get("name");
  const email = Cookies.get("email");

  // const [search, setSearch] = useState({});

  // const history = useHistory();

  const [state, setState] = useState({ data: [], isLoading: true });

  const apiUrl = "http://localhost:3001/find_favourite";

  const getApi = () => {
    axios
      .get(apiUrl, {
        user_id: props.user.user_id,
        res_id: props.restaurant.id
      })
      .then(response => {
        return response.data.restaurants.map(({ restaurant }) => {});
      })
      .then(data => {
        setState({
          data: data,
          isLoading: false
        });
      })
      .catch(error => setState({ error, isLoading: false }));
  };

  if (state.data.length === 0) {
    getApi();
  }

  return (
    <div>
      {state.isLoading ? (
        <Loading />
      ) : (
        <div>
          <NavBar />
          <div className="UserProfilecard">
            <img
              class="card-img-top"
              src="https://joeschmoe.io/api/v1/random"
              alt="Card image"
            />
          </div>
          <div class="profile-card-body">
            <h4 class="card-title">Username: {user}</h4>
            <p class="card-text">email : {email}</p>
            <h3>Your favourite restuarents are:</h3>
          </div>
          <br></br>
          {(state.data || []).map(props => {
            return (
              <Link
                style={{ textDecoration: "none", color: "white" }}
                to={`/restaurant/${props.id}`}
              >
                <SearchDescription
                  key={`${props.id}`}
                  {...props}
                ></SearchDescription>
              </Link>
            );
          })}
          <br></br>
          <Footer />
        </div>
      )}
    </div>
  );
}
